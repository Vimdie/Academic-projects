CREATE TABLE Matiere (
  idMatiere INTEGER  NOT NULL   IDENTITY ,
  NomMatiere VARCHAR(20)    ,
  Description VARCHAR(255)      ,
PRIMARY KEY(idMatiere));
GO




CREATE TABLE Filiere (
  idFiliere INTEGER  NOT NULL   IDENTITY ,
  NomFiliere VARCHAR(20)    ,
  Description VARCHAR(45)      ,
PRIMARY KEY(idFiliere));
GO




CREATE TABLE AnneeAcademique (
  idAnneeacademique INTEGER  NOT NULL   IDENTITY ,
  Libelle VARCHAR(20)    ,
  DateDebut DATE    ,
  DateFin DATE      ,
PRIMARY KEY(idAnneeacademique));
GO




CREATE TABLE Utilisateur (
  idUtilisateur INTEGER  NOT NULL   IDENTITY ,
  Email VARCHAR(45)    ,
  MotDePasse VARCHAR(255)    ,
  Role VARCHAR(20)      ,
PRIMARY KEY(idUtilisateur)  );
GO


CREATE UNIQUE INDEX Utilisateur_mail_unique ON Utilisateur (Email);
GO




CREATE TABLE Professeur (
  idProfesseur INTEGER  NOT NULL   IDENTITY ,
  Utilisateur_idUtilisateur INTEGER  NOT NULL  ,
  NomProfesseur VARCHAR(20)    ,
  PrenomProfesseur VARCHAR(20)    ,
  Telephone VARCHAR(20)    ,
  GradeSpecialite VARCHAR(45)    ,
  AnneeEmbauche INTEGER    ,
  Statu VARCHAR(20)      ,
PRIMARY KEY(idProfesseur)  ,
  FOREIGN KEY(Utilisateur_idUtilisateur)
    REFERENCES Utilisateur(idUtilisateur));
GO


CREATE INDEX Professeur_FKIndex1 ON Professeur (Utilisateur_idUtilisateur);
GO


CREATE INDEX IFK_Rel_15 ON Professeur (Utilisateur_idUtilisateur);
GO


CREATE TABLE Classe (
  idClasse INTEGER  NOT NULL   IDENTITY ,
  Filiere_idFiliere INTEGER  NOT NULL  ,
  NomClasse VARCHAR(20)      ,
PRIMARY KEY(idClasse)  ,
  FOREIGN KEY(Filiere_idFiliere)
    REFERENCES Filiere(idFiliere));
GO


CREATE INDEX Classe_FKIndex1 ON Classe (Filiere_idFiliere);
GO


CREATE INDEX IFK_Rel_01 ON Classe (Filiere_idFiliere);
GO


CREATE TABLE Etudiant (
  idEtudiant INTEGER  NOT NULL   IDENTITY ,
  Utilisateur_idUtilisateur INTEGER  NOT NULL  ,
  Matricule VARCHAR(20)    ,
  Nom VARCHAR(20)    ,
  Prenom VARCHAR(20)    ,
  Sexe CHAR(1)    ,
  DateNaissance DATE    ,
  Nationalite VARCHAR(20)    ,
  Telephone VARCHAR(20)    ,
  Boursier BIT   DEFAULT 0   ,
PRIMARY KEY(idEtudiant)    ,
  FOREIGN KEY(Utilisateur_idUtilisateur)
    REFERENCES Utilisateur(idUtilisateur));
GO


CREATE INDEX Etudiant_FKIndex1 ON Etudiant (Utilisateur_idUtilisateur);
GO
CREATE INDEX Etudiant_matricule_unique ON Etudiant (Matricule);
GO


CREATE INDEX IFK_Rel_16 ON Etudiant (Utilisateur_idUtilisateur);
GO


CREATE TABLE Administrateur (
  idAdministrateur INTEGER  NOT NULL   IDENTITY ,
  Filiere_idFiliere INTEGER    ,
  Utilisateur_idUtilisateur INTEGER  NOT NULL  ,
  Nom VARCHAR(20)    ,
  Prenom VARCHAR(20)    ,
  Telephone VARCHAR(20)    ,
  TypeAdmin VARCHAR(20)      ,
PRIMARY KEY(idAdministrateur)    ,
  FOREIGN KEY(Utilisateur_idUtilisateur)
    REFERENCES Utilisateur(idUtilisateur),
  FOREIGN KEY(Filiere_idFiliere)
    REFERENCES Filiere(idFiliere));
GO


CREATE INDEX Administrateur_FKIndex1 ON Administrateur (Utilisateur_idUtilisateur);
GO
CREATE INDEX Administrateur_FKIndex2 ON Administrateur (Filiere_idFiliere);
GO


CREATE INDEX IFK_Rel_14 ON Administrateur (Utilisateur_idUtilisateur);
GO
CREATE INDEX IFK_Rel_17 ON Administrateur (Filiere_idFiliere);
GO


CREATE TABLE Programme (
  idProgramme INTEGER  NOT NULL   IDENTITY ,
  Classe_idClasse INTEGER  NOT NULL  ,
  Matiere_idMatiere INTEGER  NOT NULL  ,
  AnneeAcademique_idAnneeacademique INTEGER  NOT NULL  ,
  Semestre VARCHAR(20)    ,
  VolumeHoraire INTEGER    ,
  Credit DECIMAL(3,1)      ,
PRIMARY KEY(idProgramme)        ,
  FOREIGN KEY(AnneeAcademique_idAnneeacademique)
    REFERENCES AnneeAcademique(idAnneeacademique),
  FOREIGN KEY(Classe_idClasse)
    REFERENCES Classe(idClasse),
  FOREIGN KEY(Matiere_idMatiere)
    REFERENCES Matiere(idMatiere));
GO


CREATE INDEX Programme_FKIndex1 ON Programme (AnneeAcademique_idAnneeacademique);
GO
CREATE INDEX Programme_FKIndex2 ON Programme (Classe_idClasse);
GO
CREATE INDEX Programme_FKIndex3 ON Programme (Matiere_idMatiere);
GO
CREATE UNIQUE INDEX Programme_unique ON Programme (Classe_idClasse, Matiere_idMatiere, AnneeAcademique_idAnneeacademique);
GO


CREATE INDEX IFK_Rel_03 ON Programme (AnneeAcademique_idAnneeacademique);
GO
CREATE INDEX IFK_Rel_04 ON Programme (Classe_idClasse);
GO
CREATE INDEX IFK_Rel_05 ON Programme (Matiere_idMatiere);
GO


CREATE TABLE Inscription (
  idInscription INTEGER  NOT NULL   IDENTITY ,
  AnneeAcademique_idAnneeacademique INTEGER  NOT NULL  ,
  Classe_idClasse INTEGER  NOT NULL  ,
  Etudiant_idEtudiant INTEGER  NOT NULL  ,
  Redoublant BIT   DEFAULT 0   ,
PRIMARY KEY(idInscription)        ,
  FOREIGN KEY(Etudiant_idEtudiant)
    REFERENCES Etudiant(idEtudiant),
  FOREIGN KEY(Classe_idClasse)
    REFERENCES Classe(idClasse),
  FOREIGN KEY(AnneeAcademique_idAnneeacademique)
    REFERENCES AnneeAcademique(idAnneeacademique));
GO


CREATE INDEX Inscription_FKIndex1 ON Inscription (Etudiant_idEtudiant);
GO
CREATE INDEX Inscription_FKIndex2 ON Inscription (Classe_idClasse);
GO
CREATE INDEX Inscription_FKIndex3 ON Inscription (AnneeAcademique_idAnneeacademique);
GO
CREATE UNIQUE INDEX Inscription_unique ON Inscription (Etudiant_idEtudiant, AnneeAcademique_idAnneeacademique);
GO


CREATE INDEX IFK_Rel_11 ON Inscription (Etudiant_idEtudiant);
GO
CREATE INDEX IFK_Rel_12 ON Inscription (Classe_idClasse);
GO
CREATE INDEX IFK_Rel_13 ON Inscription (AnneeAcademique_idAnneeacademique);
GO


CREATE TABLE Enseignement (
  idEnseignement INTEGER  NOT NULL   IDENTITY ,
  Programme_idProgramme INTEGER  NOT NULL  ,
  Professeur_idProfesseur INTEGER  NOT NULL  ,
  ModeCours VARCHAR(20)      ,
PRIMARY KEY(idEnseignement)      ,
  FOREIGN KEY(Professeur_idProfesseur)
    REFERENCES Professeur(idProfesseur),
  FOREIGN KEY(Programme_idProgramme)
    REFERENCES Programme(idProgramme));
GO


CREATE INDEX Ensegnement_FKIndex1 ON Enseignement (Professeur_idProfesseur);
GO
CREATE INDEX Ensegnement_FKIndex2 ON Enseignement (Programme_idProgramme);
GO
CREATE UNIQUE INDEX Enseignement_unique ON Enseignement (Professeur_idProfesseur, Programme_idProgramme);
GO


CREATE INDEX IFK_Rel_07 ON Enseignement (Professeur_idProfesseur);
GO
CREATE INDEX IFK_Rel_18 ON Enseignement (Programme_idProgramme);
GO


CREATE TABLE Evaluation (
  idEvaluation INTEGER  NOT NULL   IDENTITY ,
  Enseignement_idEnseignement INTEGER  NOT NULL  ,
  TypeEvaluation VARCHAR(20)    ,
  Coefficient DECIMAL(3,2)    ,
  DateEvaluation DATE      ,
PRIMARY KEY(idEvaluation)  ,
  FOREIGN KEY(Enseignement_idEnseignement)
    REFERENCES Enseignement(idEnseignement));
GO


CREATE INDEX Evaluation_FKIndex1 ON Evaluation (Enseignement_idEnseignement);
GO


CREATE INDEX IFK_Rel_08 ON Evaluation (Enseignement_idEnseignement);
GO


CREATE TABLE Absences (
  idAbsences INTEGER  NOT NULL   IDENTITY ,
  Inscription_idInscription INTEGER  NOT NULL  ,
  Enseignement_idEnseignement INTEGER  NOT NULL  ,
  DateSeance DATE    ,
  Justifier BIT   DEFAULT 0 ,
  NbHeure INTEGER      ,
PRIMARY KEY(idAbsences)    ,
  FOREIGN KEY(Enseignement_idEnseignement)
    REFERENCES Enseignement(idEnseignement),
  FOREIGN KEY(Inscription_idInscription)
    REFERENCES Inscription(idInscription));
GO


CREATE INDEX Absences_FKIndex1 ON Absences (Enseignement_idEnseignement);
GO
CREATE INDEX Absences_FKIndex2 ON Absences (Inscription_idInscription);
GO


CREATE INDEX IFK_Rel_21 ON Absences (Enseignement_idEnseignement);
GO
CREATE INDEX IFK_Rel_22 ON Absences (Inscription_idInscription);
GO


CREATE TABLE Note (
  idNote INTEGER  NOT NULL   IDENTITY ,
  Inscription_idInscription INTEGER  NOT NULL  ,
  Evaluation_idEvaluation INTEGER  NOT NULL  ,
  Note DECIMAL(4,2)    ,
  Valide VARCHAR(20)    ,
  Session VARCHAR(20)      ,
PRIMARY KEY(idNote)      ,
  FOREIGN KEY(Evaluation_idEvaluation)
    REFERENCES Evaluation(idEvaluation),
  FOREIGN KEY(Inscription_idInscription)
    REFERENCES Inscription(idInscription));
GO


CREATE INDEX Note_FKIndex1 ON Note (Evaluation_idEvaluation);
GO
CREATE UNIQUE INDEX Note_unique ON Note (Evaluation_idEvaluation, Inscription_idInscription, Session);
GO
CREATE INDEX Note_FKIndex2 ON Note (Inscription_idInscription);
GO


CREATE INDEX IFK_Rel_09 ON Note (Evaluation_idEvaluation);
GO
CREATE INDEX IFK_Rel_20 ON Note (Inscription_idInscription);
GO



